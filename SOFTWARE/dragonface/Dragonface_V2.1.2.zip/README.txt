Dragonface is a tool used to modify an existing Android image. You can edit both the images suitable for NAND or the images suitable for a microSD card. The tool is especially helpful if you attempt to configure a specific video output. To do so first run Run DragonFace.exe. Then you have to load the current Android image. Press Firmware buton in DragonFace and after loading the image in Advanced settings tab select System configurations and change the parameters in [lcd0_para] section.

Save the image with different name using Save buton and load the new image with Live Suit or Phoenix Suit (depending on the board that you have).

Note that not all resolutions are possible. However, it is always worth a try.



